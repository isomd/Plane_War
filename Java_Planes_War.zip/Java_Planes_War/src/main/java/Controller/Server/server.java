package Controller.Server;

import model.user_Server.Service.Impl.UserServerImpl;
import model.user_Server.entity.UserInfoVO;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class server implements Runnable{
    UserServerImpl userServer = new UserServerImpl();

    private static ServerSocket serverSocket = null;
    private BufferedReader reader = null;
    private BufferedWriter writer = null;
    private Socket socket;

    public server(ServerSocket serverSocket , Socket socket) throws ClassNotFoundException {
        server.serverSocket = serverSocket;
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            reader = new BufferedReader(
                    new InputStreamReader(socket.getInputStream())
            );
            writer = new BufferedWriter(
                    new OutputStreamWriter(socket.getOutputStream())
            );

            String msg;
            UserInfoVO userInfoVO;
            while((msg = reader.readLine()) != null){
                switch (msg) {
                    case "Login Message:" -> {
                        userInfoVO = userServer.Login(reader.readLine(), reader.readLine());
                        if (userInfoVO != null) {
                            writer.write(userInfoVO.toString());
                        } else {
                            writer.write("");
                        }
                        writer.newLine();
                        writer.flush();
                    }
                    case "Register Message:" -> {
                        userInfoVO = userServer.Register(reader.readLine(), reader.readLine(), reader.readLine());
                        if (userInfoVO != null) {
                            writer.write(userInfoVO.toString());
                        } else {
                            writer.write("");
                        }
                        writer.newLine();
                        writer.flush();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                this.reader.close();
                this.writer.close();
                this.socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        try {
            serverSocket = new ServerSocket (8888);
            System.out.println ("监听用户连接......");
            while (true) {//客户端的端口正确才能接下去访问，否则要么等待要么报错
                Socket socket = serverSocket.accept();//监听,阻塞连接
                System.out.println(socket.getInetAddress() + ": " + socket.getPort());
                Thread thread = new Thread(new server(serverSocket, socket));
                thread.start();
            }
        } catch (Exception e) {
            System.out.println("结束");
        }
    }
}
