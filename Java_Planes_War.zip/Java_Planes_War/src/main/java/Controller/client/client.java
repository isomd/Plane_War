package Controller.client;

import view.start.StartView;

import java.io.IOException;
import java.net.Socket;

import static view.utils.GameUtils.startView;

public class client {
    static Socket socket = null;
    public static void main(String[] args) {
            try {
                socket = new Socket("127.0.0.1", 8888);
                startView = new StartView(socket);
                startView.launch();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
    }
}