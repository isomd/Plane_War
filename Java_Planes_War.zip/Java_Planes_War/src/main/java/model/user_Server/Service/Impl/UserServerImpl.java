package model.user_Server.Service.Impl;

import model.dao.MySQLOps.Query.Query;
import model.user_Server.Mapper.UserInfoMapper;
import model.user_Server.Mapper.UserRankMapper;
import model.user_Server.Service.UserServer;
import model.user_Server.entity.UserInfoVO;
import model.user_Server.entity.UserRankVO;

import java.util.ArrayList;

public class UserServerImpl implements UserServer {
    UserInfoMapper userInfoMapper = new UserInfoMapper();
    UserRankMapper userRankMapper = new UserRankMapper();

    public UserServerImpl() throws ClassNotFoundException {
    }

    @Override
    public UserInfoVO Login(String username, String password) {
        UserInfoVO user;
        if(userInfoMapper.exist(username))
        user = userInfoMapper.selectOneByUsername(username);
        else return null;
        if(user.getPassword().equals(password))
        return user;
        return null;
    }

    @Override
    public UserInfoVO Register(String username, String password1, String password2) {
        if(!password1.equals(password2) || password1.equals("") || username.equals(""))
        return null;
        if (!userInfoMapper.exist(username))
        {
            UserInfoVO user = new UserInfoVO(username, password1, 0);
            userInfoMapper.insert(user);
            return user;
        }
        return null;
    }

    @Override
    public ArrayList<UserRankVO> getRankingList(int gameLevel) {
        Query query = new Query();
        query.eqAnd("passGameLevel", gameLevel);
        query.limit(10);

        return userRankMapper.selectAll(query);
    }
}
