package model.user_Server.Service;

import model.user_Server.entity.UserInfoVO;
import model.user_Server.entity.UserRankVO;

import java.sql.SQLException;
import java.util.ArrayList;

public interface UserServer {
    UserInfoVO Login(String username, String password);

    UserInfoVO Register(String username, String password1, String password2);

    ArrayList<UserRankVO> getRankingList(int gameLevel);
}
