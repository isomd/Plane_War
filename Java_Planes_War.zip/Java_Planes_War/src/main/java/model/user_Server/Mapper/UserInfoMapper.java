package model.user_Server.Mapper;

import model.dao.MySQLOps.MySQLOpsImpl.MySQLOpsImpl;
import model.user_Server.entity.UserInfoVO;

public class UserInfoMapper extends MySQLOpsImpl<UserInfoVO> {
    public UserInfoMapper() throws ClassNotFoundException {
    }
}
