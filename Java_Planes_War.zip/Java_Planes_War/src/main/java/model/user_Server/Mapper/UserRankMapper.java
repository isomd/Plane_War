package model.user_Server.Mapper;

import model.dao.MySQLOps.MySQLOpsImpl.MySQLOpsImpl;
import model.user_Server.entity.UserRankVO;

public class UserRankMapper extends MySQLOpsImpl<UserRankVO> {
    public UserRankMapper() throws ClassNotFoundException {
    }
}
