package model.user_Server.entity;

import lombok.Data;
import model.dao.Annontation.Table;

@Table(TableName = "user")
@Data
public class UserInfoVO {
    private String username;

    private String password;

    private int passGameLevel;

    public UserInfoVO(String username, String password, int passGameLevel) {
        this.username = username;
        this.password = password;
        this.passGameLevel = passGameLevel;
    }

    public UserInfoVO() {
    }
    public void valueForString(String s){
        this.username = s.split(" ")[0];
        this.password = s.split(" ")[1];
        this.passGameLevel = Integer.parseInt(s.split(" ")[2]);
    }

    @Override
    public String toString() {
        return username + ' ' + password + ' ' + passGameLevel;
    }
}
