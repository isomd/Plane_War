package model.user_Server.entity;

import lombok.Data;
import lombok.ToString;
import model.dao.Annontation.Table;

@Table(TableName = "user_ranking_list")
@Data
@ToString
public class UserRankVO {
    private String username;

    private int passGameLevel;

    private int score;

    public UserRankVO(String username, int passGameLevel, int score) {
        this.username = username;
        this.passGameLevel = passGameLevel;
        this.score = score;
    }

    public UserRankVO() {
    }
}
