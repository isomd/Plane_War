package model.dao.MySQLOps.Query;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class Query{
    private StringBuilder sql = new StringBuilder();
    public Query() {
    }

    public void eqOr(String fieldName, Object fieldValue){
        if(!sql.isEmpty()){
            sql.append(" or ");
        }
        else {
            sql.append(" where ");
        }
        sql.append(fieldName).append("=").append('\'').append(fieldValue).append('\'');
    }

    public void eqAnd(String fieldName, Object fieldValue){
        if(!sql.isEmpty()){
            sql.append(" and ");
        } else {
            sql.append(" where ");
        }
        sql.append(fieldName).append("=").append('\'').append(fieldValue).append('\'');
    }

    public void orderBy(String fieldName, boolean flag){
        sql.append(" order by ").append(fieldName);
        if(flag) sql.append(" asc");
        else sql.append(" desc");
    }

    public void groupBy(String fieldName){
        sql.append(" group by ").append(fieldName);
    }

    public void limit(int level){
        sql.append(" limit ").append(level);
    }

    public void limit(int minLevel, int maxLevel){
        sql.append(" limit ").append(minLevel).append(",").append(maxLevel);
    }

    public String getSql() {
        return sql.toString();
    }
}