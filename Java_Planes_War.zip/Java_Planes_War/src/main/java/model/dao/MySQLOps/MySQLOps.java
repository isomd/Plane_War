package model.dao.MySQLOps;


import model.dao.MySQLOps.Query.Query;

import java.sql.SQLException;
import java.util.ArrayList;

public interface MySQLOps<T> {
    T selectOne(Query query);

    ArrayList<T> selectAll(Query query);

    ArrayList<T> selectForNum(Query query, int num);

    boolean exist(Query query);

    T selectOneByUsername(String username) throws SQLException;

    ArrayList<T> selectAllByUsername(String username);

    String getTableName() throws ClassNotFoundException;

    void copyProperties(Object target, Object source);

    void upData(T t) throws SQLException, IllegalAccessException;

    void insert(T t) throws SQLException;

    boolean exist(String username);

}
