package model.dao.MySQLOps.MySQLOpsImpl;

import model.dao.Annontation.Table;
import model.dao.MySQLOps.MySQLOps;
import model.dao.MySQLOps.Query.Query;
import model.dao.connect.ConnectMySQL;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


//@SuppressWarnings("all")
public class MySQLOpsImpl<T> implements MySQLOps<T> {
    private final ParameterizedType parameterizedType = (ParameterizedType) getClass().getGenericSuperclass();
    private final Type type = parameterizedType.getActualTypeArguments()[0];
    private final String tableName;

    public MySQLOpsImpl() throws ClassNotFoundException {
        tableName = getTableName();
    }

    @Override
    public T selectOne(Query query) {
        ConnectMySQL connectMySQL = new ConnectMySQL();
        try {
            Statement statement = connectMySQL.connect();
            assert statement != null;

            T t = ((Class<T>) type).getConstructor().newInstance();
            query.limit(1);
            ResultSet result = statement.executeQuery("select * from " + tableName + query.getSql());
            copyToData(t, result);
            return t;
        } catch (InvocationTargetException | InstantiationException | SQLException | IllegalAccessException | NoSuchMethodException e) {
            e.printStackTrace();
        } finally {
            connectMySQL.close();
        }
        return null;
    }

    @Override
    public ArrayList<T> selectAll(Query query) {
        ConnectMySQL connectMySQL = new ConnectMySQL();
        try {
            Statement statement = connectMySQL.connect();
            assert statement != null;

            ArrayList<T> list = new ArrayList<>();

            ResultSet result = statement.executeQuery("select * from " + tableName + query.getSql());
            copyToData(list, result);
            return list;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connectMySQL.close();
        }
        return null;
    }

    @Override
    public ArrayList<T> selectForNum(Query query, int num) {
        ConnectMySQL connectMySQL = new ConnectMySQL();
        try {
            Statement statement = connectMySQL.connect();
            assert statement != null;

            ArrayList<T> list = new ArrayList<>();

            query.limit(num);

            ResultSet result = statement.executeQuery("select * from " + tableName + query.getSql());
            copyToData(list, result);
            return list;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connectMySQL.close();
        }
        return null;
    }

    @Override
    public T selectOneByUsername(String username) {
        ConnectMySQL connectMySQL = new ConnectMySQL();
        try {
            Statement statement = connectMySQL.connect();
            assert statement != null;

            T t = ((Class<T>) type).getConstructor().newInstance();
            ResultSet result = statement.executeQuery("select * from " + tableName + " where username=" + '\'' + username + '\'' + "limit 1");
            copyToData(t, result);
            return t;
        } catch (InvocationTargetException | InstantiationException | SQLException | IllegalAccessException | NoSuchMethodException e) {
            e.printStackTrace();
        } finally {
            connectMySQL.close();
        }
        return null;
    }

    @Override
    public ArrayList<T> selectAllByUsername(String username) {
        ConnectMySQL connectMySQL = new ConnectMySQL();
        try {
            Statement statement = connectMySQL.connect();
            assert statement != null;

            ArrayList<T> list = new ArrayList<>();
            ResultSet result = statement.executeQuery("select * from " + tableName + " where username=" + '\'' + username + '\'' + "limit 1");
            copyToData(list, result);
            return list;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connectMySQL.close();
        }
        return null;
    }

    @Override
    public String getTableName() throws ClassNotFoundException {
        Class<?> c = Class.forName(type.getTypeName());
        boolean hasAnnotation = c.isAnnotationPresent(Table.class);
        if (hasAnnotation) {
            Table table = c.getAnnotation(Table.class);
            return table.TableName();
        }
        return null;
    }

    @Override
    public void upData(T t) {
        ConnectMySQL connectMySQL = new ConnectMySQL();
        try {
            //获得数据库连接
            Statement statement = connectMySQL.connect();
            assert statement != null;

            //反射获得类的值和类的名字 然后设置到数据库中
            Field[] field = t.getClass().getDeclaredFields();
            field[0].setAccessible(true);
            for (int i = 1; i < field.length; i++) {
                field[i].setAccessible(true);
                statement.executeUpdate("update " + tableName + " set " + field[i].getName() + "=" + '\'' + field[i].get(t) + '\'' + " where " + field[0].getName() + "=" + '\'' + field[0].get(t) + '\'');
            }

        } catch (SQLException | IllegalAccessException e) {
            e.printStackTrace();
        } finally {
            connectMySQL.close();
        }
    }

    @Override
    public void insert(T t) {
        ConnectMySQL connectMySQL = new ConnectMySQL();
        try {
            Statement statement = connectMySQL.connect();
            assert statement != null;


            String sql = "insert into " + tableName;
            StringBuilder key = new StringBuilder(" (");
            StringBuilder value = new StringBuilder(" (");

            //通过反射获得的值于名称，用于构建sql语句
            Field[] field = t.getClass().getDeclaredFields();
            field[0].setAccessible(true);
            key.append(field[0].getName());
            value.append('\'').append(field[0].get(t));
            for (int i = 1; i < field.length; i++) {
                field[i].setAccessible(true);
                key.append(",").append(field[i].getName());
                value.append('\'' + "," + '\'').append(field[i].get(t));
            }
            sql += key + ") values " + value + '\'' + ")";
            statement.executeUpdate(sql);
        } catch (IllegalAccessException | SQLException e) {
            e.printStackTrace();
        } finally {
            connectMySQL.close();
        }
    }

    @Override
    public boolean exist(String username) {
        ConnectMySQL connectMySQL = new ConnectMySQL();
        try {
            Statement statement = connectMySQL.connect();
            assert statement != null;

            ResultSet result = statement.executeQuery("select count(*) from " + tableName + " where username=" + '\'' + username + '\'');
            if (result.next()) {
                if (!result.getObject("count(*)").toString().equals("0"))
                    return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connectMySQL.close();
        }
        return false;
    }

    @Override
    public boolean exist(Query query) {
        ConnectMySQL connectMySQL = new ConnectMySQL();
        try {
            Statement statement = connectMySQL.connect();
            assert statement != null;

            ResultSet result = statement.executeQuery("select count(*) from " + tableName + query.getSql());
            if (result.next()) {
                if (!result.getObject("count(*)").toString().equals("0"))
                    return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            connectMySQL.close();
        }
        return false;
    }

    @Override
    public void copyProperties(Object source, Object target) {
        if (target == null || source == null) {
            return;
        }

        //反射从拷贝source和target相同成员名的值
        Field[] fieldTarget = target.getClass().getDeclaredFields();
        Field[] fieldSource = source.getClass().getDeclaredFields();
        try {
            for (int i = 0; i < fieldTarget.length; i++) {
                for (int j = 0; j < fieldSource.length; j++) {
                    if (fieldTarget[i].getName().equals(fieldSource[j].getName()) &&
                            fieldTarget[i].getGenericType().toString().equals(fieldSource[i].getGenericType().toString())) {
                        fieldTarget[i].setAccessible(true);
                        fieldSource[j].setAccessible(true);
                        fieldTarget[j].set(target, fieldSource[i].get(source));
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void copyToData(T t, ResultSet result) {
        Field[] fieldTarget = t.getClass().getDeclaredFields();

        try {
            while (result.next())
                for (Field field : fieldTarget) {
                    field.setAccessible(true);
                    field.set(t, result.getObject(field.getName()));
                }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void copyToData(ArrayList<T> t, ResultSet result) {
        int len = 0;
        try {
            while (result.next()) {
                t.add(((Class<T>) type).getConstructor().newInstance());
                Field[] fieldTarget = t.get(len).getClass().getDeclaredFields();
                for (Field field : fieldTarget) {
                    field.setAccessible(true);
                    field.set(t.get(len), result.getObject(field.getName()));
                }
                len++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
//class test{
//    public static void main(String[] args) throws ClassNotFoundException {
//        UserInfoMapper userInfoMapper = new UserInfoMapper();
//        Query query = new Query();
//        query.eqAnd("username", "1234");
//        System.out.println(userInfoMapper.exist("1234"));
//    }
//}