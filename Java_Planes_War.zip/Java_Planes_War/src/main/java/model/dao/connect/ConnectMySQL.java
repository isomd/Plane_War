package model.dao.connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectMySQL {
    Connection connection;
    public Statement connect()
    {
        String sql_name = "root";
        String sql_password = "1113";
        String url = "jdbc:mysql://localhost:3306/plane_war";
        String driverName = "com.mysql.cj.jdbc.Driver";
        try{
            Class.forName(driverName);      //加载驱动
            connection = DriverManager.getConnection(url,sql_name,sql_password);     //加载数据库，获得连接对象          参数：数据库位置，名称，密码
            return connection.createStatement();
        } catch (Exception e){
            e.printStackTrace();
            System.out.println("错误，已停止");
        }
        return null;
    }
    public void close(){
        try {
            connection.close();
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
}
