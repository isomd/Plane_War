package view.gameplaying;

import view.KeyListener.MyKeyListener;
import view.endView.EndView;
import view.entity.*;
import view.utils.GameUtils;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.Random;

import static view.utils.GameUtils.endView;

public class GamePlayingView extends JFrame {
    String username;

    boolean endFlag = false;

    boolean bossFlag = false;

    public static int GameScore = 0;

    boolean doubleFlag = false;

    Random random = new Random();

    int passGameLevel;

    //窗口大小
    public static final int WIDTH = 512;
    public static final int HEIGHT = 768;
    //创建双缓冲
    Image offScreenImage = null;
    //设置本机对象
    MyPlane myPlane1 = new MyPlane(GameUtils.myPlaneImage, 225, 600, 100, 85, 1, 100);
    MyPlane myPlane2 = new MyPlane(GameUtils.myPlaneImage, 225, 600, 100, 85, 1, 100);
    //统计刷新次数
    int count = 1;

    public GamePlayingView(int passGameLevel, String username) {
        this.passGameLevel = passGameLevel;
        this.username = username;
        GameScore = 0;
        GameUtils.init();
    }

    public GamePlayingView(int passGameLevel, String username, boolean doubleFlag) throws HeadlessException, IOException {
        this.username = username;
        this.passGameLevel = passGameLevel;
        this.doubleFlag = doubleFlag;
        GameScore = 0;
        GameUtils.init();
    }

    //界面开始
    public void launch() throws InterruptedException, ClassNotFoundException, IOException {
        this.setIconImage(GameUtils.IconImage);
        this.setSize(WIDTH, HEIGHT);
        this.setTitle("独一无二的飞机大战");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //添加键盘监听
        this.addKeyListener(new MyKeyListener());
        setBackgroundImage(passGameLevel);
        //将myPlane添加到游戏对象中
        GameUtils.myPlanes.add(myPlane1);
        if(doubleFlag)
        GameUtils.myPlanes.add(myPlane2);
        createEnemy();

        direction();
        //循环画图刷新
        this.setVisible(true);
        while (!endFlag) {
            this.repaint();
            count++;
            //设置我方生成子弹速度
            if (count % 20 == 0)
                createShell();
            if(count > 100 && !bossFlag)
            {
                createBoss();
                bossFlag = true;
            }
            if (count <= 1000 && count % 100 == 0){
                createEnemy();
            }
            if (count % 1000 == 0){
                createProp();
            }
            //设置敌机的移动
            for (EnemyObject enemyObject: GameUtils.enemyObjects){
                enemyObject.move();
                enemyObject.fire(this, myPlane1);
            }
            //对游戏对象的判断
            judge();
            Thread.sleep(13);
        }
        endView = new EndView(GameScore, passGameLevel, username);
        endView.launch();
        dispose();
    }

    void judge() {
        //判断第一颗子弹有没有超出边界，如果超出则删除
        if (!GameUtils.shellObjects.isEmpty() && !GameUtils.shellObjects.get(0).isInArea()) {
            GameUtils.shellObjects.remove(0);
        }
        //判断敌方子弹是否超出边界，如果超出则删除
        if(!GameUtils.enemyShellObject.isEmpty() && !GameUtils.enemyShellObject.get(0).isInArea()){
            GameUtils.enemyShellObject.remove(0);
        }
        //判断游戏对象是否血量归零，归零则删除
        for (int i = 0; i < GameUtils.enemyObjects.size(); i ++)
        {
            if(GameUtils.enemyObjects.get(i).getBlood() <= 0)
            {
                GameUtils.BombObjects.add(new BombObject(GameUtils.enemyObjects.get(i).getX(), GameUtils.enemyObjects.get(i).getY()));
                GameUtils.enemyObjects.remove(i);
                GameScore += 10;
                if(bossFlag && GameUtils.enemyObjects.size() == 0)
                    GameScore += 1000;
                break;
            }
        }
        //判断敌方子弹是否击中我方飞机
        for (GameObject myPlane : GameUtils.myPlanes)
            for (int i = 0; i < GameUtils.enemyShellObject.size(); i ++)
                if (GameUtils.enemyShellObject.get(i).isImpact(myPlane))
                {
                    myPlane.setBlood(myPlane.getBlood() - GameUtils.enemyShellObject.get(i).getBlood());
                    GameUtils.enemyShellObject.remove(i);
                    break;
                }
        //判断我方飞机是否血量归零
        for (int i = 0; i < GameUtils.myPlanes.size(); i ++){
            if(GameUtils.myPlanes.get(i).getBlood() <= 0)
            {
                GameUtils.BombObjects.add(new BombObject(GameUtils.myPlanes.get(i).getX(), GameUtils.myPlanes.get(i).getY()));
                GameUtils.myPlanes.remove(i);
                break;
            }
        }
        //判断我方飞机是否和道具相碰
        for (GameObject myPlane : GameUtils.myPlanes){
            if(GameUtils.propObject != null && GameUtils.propObject.isImpact(myPlane)){
                GameUtils.propObject.function(myPlane);
                GameUtils.propObject = null;
            }
        }
        //判断子弹击中飞机
        for (EnemyObject enemyObject : GameUtils.enemyObjects)
            for (int i = 0; i < GameUtils.shellObjects.size(); i ++)
                if (GameUtils.shellObjects.get(i).isImpact(enemyObject))
                {
                    enemyObject.setBlood(enemyObject.getBlood() - GameUtils.shellObjects.get(i).getBlood());
                    GameUtils.shellObjects.remove(i);
                    break;
                }
        //判断我方飞机是否和对方飞机相撞
        for (EnemyObject enemyObject : GameUtils.enemyObjects){
            for (GameObject myPlane:GameUtils.myPlanes)
            {
                if(enemyObject.isImpact(myPlane)) {
                    myPlane.setBlood(myPlane.getBlood() - 20);
                }
            }
        }
        if(count % 30 == 0 && GameUtils.myPlanes.size() == 0 || bossFlag && count % 30 == 0 && GameUtils.enemyObjects.size() == 0) {
            endFlag = true;
            if(GameUtils.myPlanes.size() != 0)
                GameScore += 1000;
        }
    }

    void setBackgroundImage(int passGameLevel) {
            GameUtils.backgroundImage = Toolkit.getDefaultToolkit().getImage("D:\\IDEA\\Java_Planes_War\\src\\main\\resources\\image\\场景" + passGameLevel + ".jpg");
    }

    @Override
    public void paint(Graphics g) {
        //如果双缓冲从未刷新过，则创建
        if (offScreenImage == null) {
            offScreenImage = createImage(WIDTH, HEIGHT);
        }
        //获得双缓冲的画笔
        Graphics graphics = offScreenImage.getGraphics();
        //画背景图片
        graphics.drawImage(GameUtils.backgroundImage, 0, 0, null);
        //把所有的游戏对象画到双缓冲中
        for (EnemyObject gameObject : GameUtils.enemyObjects) {
            gameObject.paintSelf(graphics);
        }
        for (GameObject gameObject: GameUtils.myPlanes){
            gameObject.paintSelf(graphics);
        }
        //将道具画到缓冲中
        if(GameUtils.propObject != null)
        GameUtils.propObject.paintSelf(graphics);
        //将敌机子弹画到缓冲中
        for (ShellObject shellObject: GameUtils.enemyShellObject){
            shellObject.enemyShellPaint(graphics);
        }
        //画爆炸效果
        for (int i = 0;i < GameUtils.BombObjects.size();i ++){
            if(GameUtils.BombObjects.get(i).getCount() >= 32) {
                GameUtils.BombObjects.remove(i);
                continue;
            }
            GameUtils.BombObjects.get(i).paintSelf(graphics);
        }
        //把所有的子弹画到双缓冲中
        for (ShellObject shellObject : GameUtils.shellObjects) {
            shellObject.paintSelf(graphics);
        }
        //画到窗口中
        g.drawImage(offScreenImage, 0, 0, null);
    }
    //生成子弹
    public void createShell() {
        for (GameObject myPlane:GameUtils.myPlanes)
        GameUtils.shellObjects.add(new ShellObject(GameUtils.shellImage, myPlane.getX() + myPlane.getWidth() / 2 - 15, myPlane.getY(), 29, 65, 5, 50));
    }
    //生成敌人
    public void createEnemy() {
        GameUtils.enemyObjects.add(new EnemyObject(GameUtils.enemyPlaneImage, Math.abs(random.nextInt() % (WIDTH - 88)), -63 , 88, 63, 1, 100));
    }
    //生成道具
    public void createProp() {
        switch (random.nextInt() % 2) {
            case 0 -> GameUtils.propObject = new BloodPropObject(GameUtils.bloodPropImage, Math.abs(random.nextInt() % (WIDTH - 50)), -65, 50, 45);
            case 1 -> GameUtils.propObject = new BombPropObject(GameUtils.bombPropImage, Math.abs(random.nextInt() % (WIDTH - 61)), -60, 61, 57);
        }
    }
    public void createBoss() {
        GameUtils.enemyObjects.add(new BossObject(GameUtils.bossImage, 0, 0, 300, 154, 1, 10000));
    }
    void direction(){
        Thread thread_left = new Thread(() -> {
            while(true) {
                if (GameUtils.LEFT)
                    myPlane1.leftMove();
                try {
                    Thread.sleep(3);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        Thread thread_right = new Thread(() -> {
            while(true) {
                if (GameUtils.RIGHT)
                    myPlane1.rightMove();
                try {
                    Thread.sleep(3);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        Thread thread_up = new Thread(() -> {
            while(true) {
                if (GameUtils.UP)
                    myPlane1.upMove();
                try {
                    Thread.sleep(3);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        Thread thread_down = new Thread(() -> {
            while(true) {
                if (GameUtils.DOWN)
                    myPlane1.downMove();
                try {
                    Thread.sleep(3);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        thread_left.start();
        thread_down.start();
        thread_right.start();
        thread_up.start();
        if(doubleFlag){
            Thread thread_partnerLeft = new Thread(() -> {
                while(true) {
                    if (GameUtils.partnerLEFT)
                        myPlane2.leftMove();
                    try {
                        Thread.sleep(3);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            Thread thread_partnerRight = new Thread(() -> {
                while(true) {
                    if (GameUtils.partnerRIGHT)
                        myPlane2.rightMove();
                    try {
                        Thread.sleep(3);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            Thread thread_partnerUp = new Thread(() -> {
                while(true) {
                    if (GameUtils.partnerUP)
                        myPlane2.upMove();
                    try {
                        Thread.sleep(3);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            Thread thread_partnerDown = new Thread(() -> {
                while(true) {
                    if (GameUtils.partnerDOWN)
                        myPlane2.downMove();
                    try {
                        Thread.sleep(3);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            thread_partnerDown.start();
            thread_partnerUp.start();
            thread_partnerRight.start();
            thread_partnerLeft.start();
        }
    }
}