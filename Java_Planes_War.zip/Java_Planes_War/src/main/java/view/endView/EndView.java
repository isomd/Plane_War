package view.endView;

import model.user_Server.Mapper.UserRankMapper;
import model.user_Server.entity.UserRankVO;
import view.utils.GameUtils;

import javax.swing.*;
import javax.swing.text.BadLocationException;
import java.awt.*;
import java.nio.charset.StandardCharsets;

import static view.utils.GameUtils.mainView;

public class EndView extends JFrame {
    UserRankMapper userInfoMapper  = new UserRankMapper();

    int score;

    int gameLevel;

    String username;

    public EndView(int score, int gameLevel, String username) throws HeadlessException, ClassNotFoundException {
        this.score = score;
        this.gameLevel = gameLevel;
        this.username = username;
    }
    public void launch(){
        this.setIconImage(GameUtils.IconImage);
        this.setTitle("结束！");
        this.setSize(450,300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setFont(new Font("微软雅黑", Font.PLAIN,15));

        JTextArea scoreArea = new JTextArea();
        JButton returnButton = new JButton("返回主界面");

        scoreArea.setFont(new Font("微软雅黑", Font.PLAIN,20));
        scoreArea.setText("恭喜您！关卡" + gameLevel + "获得了" + score + "分！再接再厉！");
        scoreArea.setBounds(0, 0, (scoreArea.getText().getBytes(StandardCharsets.UTF_8).length - scoreArea.getText().length()) / 2 * 20, 60);
        scoreArea.setOpaque(false);
        scoreArea.setEditable(false);

        returnButton.setFont(new Font("微软雅黑", Font.PLAIN,20));
        returnButton.setBounds(280, 210, 150, 40);
        returnButton.addActionListener(e -> {
            userInfoMapper.insert(new UserRankVO(username, gameLevel, score));
            Thread thread = new Thread(()->{
                try {
                    mainView.launch();
                } catch (BadLocationException ex) {
                    ex.printStackTrace();
                }
            });
            thread.start();
            dispose();
        });

        this.add(returnButton);
        this.add(scoreArea);
        this.setVisible(true);
    }
}