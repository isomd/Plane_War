package view.KeyListener;

import view.utils.GameUtils;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class MyKeyListener extends KeyAdapter {

    public MyKeyListener() {
    }
    @Override
    public void keyPressed(KeyEvent e){
            int x = e.getKeyCode();
            switch (x) {
                case KeyEvent.VK_W -> GameUtils.UP = true;
                case KeyEvent.VK_S -> GameUtils.DOWN = true;
                case KeyEvent.VK_A -> GameUtils.LEFT = true;
                case KeyEvent.VK_D -> GameUtils.RIGHT = true;
                case KeyEvent.VK_LEFT -> GameUtils.partnerLEFT = true;
                case KeyEvent.VK_RIGHT -> GameUtils.partnerRIGHT = true;
                case KeyEvent.VK_UP -> GameUtils.partnerUP = true;
                case KeyEvent.VK_DOWN -> GameUtils.partnerDOWN = true;
            }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int x = e.getKeyCode();
        switch (x) {
            case KeyEvent.VK_W -> GameUtils.UP = false;
            case KeyEvent.VK_S -> GameUtils.DOWN = false;
            case KeyEvent.VK_A -> GameUtils.LEFT = false;
            case KeyEvent.VK_D -> GameUtils.RIGHT = false;
            case KeyEvent.VK_LEFT -> GameUtils.partnerLEFT = false;
            case KeyEvent.VK_RIGHT -> GameUtils.partnerRIGHT = false;
            case KeyEvent.VK_UP -> GameUtils.partnerUP = false;
            case KeyEvent.VK_DOWN -> GameUtils.partnerDOWN = false;
        }
    }
}