package view.utils;

import view.endView.EndView;
import view.entity.*;
import view.gameplaying.GamePlayingView;
import view.start.ChooseLevel;
import view.start.MainView;
import view.start.StartView;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class GameUtils {
    //图标图片
    public static Image IconImage = Toolkit.getDefaultToolkit().getImage("D:\\IDEA\\Java_Planes_War\\src\\main\\resources\\image\\图标.jpg");
    //背景图片
    public static Image backgroundImage = Toolkit.getDefaultToolkit().getImage("D:\\IDEA\\Java_Planes_War\\src\\main\\resources\\image\\场景1.jpg");
    //本机图片
    public static Image myPlaneImage = Toolkit.getDefaultToolkit().getImage("D:\\IDEA\\Java_Planes_War\\src\\main\\resources\\image\\飞机5.png");
    //敌机图片
    public static Image enemyPlaneImage = Toolkit.getDefaultToolkit().getImage("D:\\IDEA\\Java_Planes_War\\src\\main\\resources\\image\\飞机2.png");
    //敌机子弹图片
    public static Image enemyShellImage = Toolkit.getDefaultToolkit().getImage("D:\\IDEA\\Java_Planes_War\\src\\main\\resources\\image\\子弹2.png");
    //道具全屏爆炸图片
    public static Image bombPropImage = Toolkit.getDefaultToolkit().getImage("D:\\IDEA\\Java_Planes_War\\src\\main\\resources\\image\\爆炸.png");
    //道具加血图片
    public static Image bloodPropImage = Toolkit.getDefaultToolkit().getImage("D:\\IDEA\\Java_Planes_War\\src\\main\\resources\\image\\加血.png");
    //Boss图片
    public static Image bossImage = Toolkit.getDefaultToolkit().getImage("D:\\IDEA\\Java_Planes_War\\src\\main\\resources\\image\\boss1.png");
    //爆炸图片
    public static Image[] bomb = new Image[16];
    static {
        for (int i = 1;i < 17;i ++){
            bomb[i - 1] = Toolkit.getDefaultToolkit().getImage("D:\\IDEA\\Java_Planes_War\\src\\main\\resources\\image\\" + i + ".gif");
        }
    }
    //子弹图片
    public static Image shellImage = Toolkit.getDefaultToolkit().getImage("D:\\IDEA\\Java_Planes_War\\src\\main\\resources\\image\\子弹.png");
    //游戏敌人对象类集合
    public static ArrayList<EnemyObject> enemyObjects;
    //游戏我方飞机集合
    public static ArrayList<GameObject> myPlanes;
    //游戏子弹集合
    public static ArrayList<ShellObject> shellObjects;
    //敌机子弹集合
    public static ArrayList<ShellObject> enemyShellObject;
    //爆炸集合
    public static ArrayList<BombObject> BombObjects;
    //道具对象
    public static PropObject propObject;
    //读取文件
    public static StringBuilder ruleOne = new StringBuilder();
    public static StringBuilder ruleDouble = new StringBuilder();

    static {
        try {
            BufferedReader bufferedReader1 = new BufferedReader(new InputStreamReader(new FileInputStream("D:\\IDEA\\Java_Planes_War\\src\\main\\resources\\gameRule_One.txt"), StandardCharsets.UTF_8));
            BufferedReader bufferedReader2 = new BufferedReader(new InputStreamReader(new FileInputStream("D:\\IDEA\\Java_Planes_War\\src\\main\\resources\\gameRule_Double.txt"), StandardCharsets.UTF_8));
            String msg = "";
            while((msg = bufferedReader1.readLine()) != null){
                ruleOne.append("\n").append(msg);
            }
            while((msg = bufferedReader2.readLine()) != null){
                ruleDouble.append("\n").append(msg);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //本机移动方向
    public static boolean LEFT;
    public static boolean RIGHT;
    public static boolean UP;
    public static boolean DOWN;

    public static boolean partnerLEFT;
    public static boolean partnerRIGHT;
    public static boolean partnerUP;
    public static boolean partnerDOWN;

    public static ImageIcon startImage = new ImageIcon("D:\\IDEA\\Java_Planes_War\\src\\main\\resources\\image\\主界面背景.jpg");

    public static StartView startView;

    public static MainView mainView;

    public static ChooseLevel chooseLevel;

    public static GamePlayingView gamePlayingView;

    public static EndView endView;


    public static void init(){
        enemyObjects = new ArrayList<>();
        myPlanes = new ArrayList<>();
        shellObjects = new ArrayList<>();
        enemyShellObject = new ArrayList<>();
        BombObjects = new ArrayList<>();
        propObject = null;

        LEFT = false;
        RIGHT = false;
        UP = false;
        DOWN = false;
        partnerLEFT = false;
        partnerRIGHT = false;
        partnerUP = false;
        partnerDOWN = false;
    }
}