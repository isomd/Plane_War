package view.start;

import view.gameplaying.GamePlayingView;
import view.utils.GameUtils;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.Socket;
import java.util.Arrays;

import static view.utils.GameUtils.gamePlayingView;

public class ChooseLevel extends JFrame {
    int gameLevel;

    String username;

    boolean doubleFlag = false;

    public ChooseLevel(int gameLevel, String username, boolean doubleFlag) throws HeadlessException, IOException {
        this.gameLevel = gameLevel;
        this.username = username;
        this.doubleFlag = doubleFlag;
    }

    public ChooseLevel(int gameLevel, String username) throws HeadlessException {
        this.gameLevel = gameLevel;
        this.username = username;
    }

    void launch() throws IOException {
        this.setIconImage(GameUtils.IconImage);
        this.setTitle("选择关卡");
        this.setSize(390,250);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setFont(new Font("微软雅黑", Font.PLAIN,15));

            JLabel jLabel = new JLabel();
            JComboBox<Integer> chooseGameLevel = new JComboBox<>();
            JTextArea jTextArea = new JTextArea("选择关卡：");
            JButton startGame = new JButton("开始游戏");
            JTextPane rule = new JTextPane();

            if(!doubleFlag){
                rule.setText(GameUtils.ruleOne.toString());
            } else {
                rule.setText(GameUtils.ruleDouble.toString());
            }
            rule.setFont(new Font("微软雅黑", Font.PLAIN, 13));
            rule.setBounds(20, 30, 230, 170);
            rule.setOpaque(false);
            rule.setEditable(false);
            jLabel.setBounds(10, 10, 390, 220);
            for (int i = 1; i <= gameLevel; i++) {
                chooseGameLevel.addItem(i);
            }
            chooseGameLevel.setBounds(100, 20, 50, 30);
            chooseGameLevel.setFont(new Font("微软雅黑", Font.PLAIN, 20));
            jTextArea.setBounds(20, 20, 80, 30);
            jTextArea.setFont(new Font("微软雅黑", Font.PLAIN, 18));
            jTextArea.setOpaque(false);
            jTextArea.setEditable(false);
            startGame.setBounds(250, 150, 120, 50);
            startGame.setFont(new Font("微软雅黑", Font.PLAIN, 18));
            startGame.addActionListener(e -> {
                if (!doubleFlag)
                {
                    this.dispose();
                    Thread thread = new Thread(() -> {
                        gamePlayingView = new GamePlayingView((Integer) chooseGameLevel.getSelectedItem(), username);
                        try {
                            gamePlayingView.launch();
                        } catch (InterruptedException | ClassNotFoundException | IOException ex) {
                            ex.printStackTrace();
                        }
                    });
                    thread.start();
                } else {
                    this.dispose();
                    Thread thread = new Thread(() -> {
                        try {
                            gamePlayingView = new GamePlayingView((Integer) chooseGameLevel.getSelectedItem(), username, true);
                            gamePlayingView.launch();
                        } catch (InterruptedException | ClassNotFoundException | IOException ex) {
                            ex.printStackTrace();
                        }
                    });
                    thread.start();
                }
            });
            jLabel.add(chooseGameLevel);
            jLabel.add(jTextArea);
            jLabel.add(startGame);
            jLabel.add(rule);
            this.add(jLabel);
            this.setVisible(true);
    }
}