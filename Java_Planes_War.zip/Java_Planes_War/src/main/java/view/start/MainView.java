package view.start;

import model.dao.MySQLOps.Query.Query;
import model.user_Server.Mapper.UserRankMapper;
import model.user_Server.entity.UserInfoVO;
import model.user_Server.entity.UserRankVO;
import view.utils.GameUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.BadLocationException;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import java.awt.*;
import java.io.IOException;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import static view.utils.GameUtils.chooseLevel;
import static view.utils.GameUtils.startView;

public class MainView extends JFrame {
    Socket socket = null;

    int nameSize;

    int gameLevel;

    UserInfoVO userInfoVO;

    ArrayList<UserRankVO> rankList = new ArrayList<>();

    UserRankMapper userRankMapper = new UserRankMapper();

    public MainView(UserInfoVO userInfoVO, int gameLevel, Socket socket) throws HeadlessException, ClassNotFoundException {
        this.socket = socket;
        this.gameLevel = gameLevel;
        this.userInfoVO = userInfoVO;
        nameSize = (userInfoVO.getUsername().getBytes(StandardCharsets.UTF_8).length + userInfoVO.getUsername().length()) / 2;
    }

    public MainView(UserInfoVO userInfoVO, int gameLevel) throws HeadlessException, ClassNotFoundException {
        this.userInfoVO = userInfoVO;
        this.gameLevel = gameLevel;
        nameSize = (userInfoVO.getUsername().getBytes(StandardCharsets.UTF_8).length + userInfoVO.getUsername().length()) / 2;
    }
    public void launch() throws BadLocationException {
        this.setIconImage(GameUtils.IconImage);
        this.setTitle("独一无二的飞机大战");
        this.setSize(640,400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setFont(new Font("微软雅黑", Font.PLAIN,15));

        JLabel background = new JLabel(GameUtils.startImage);
        JPanel jPanel = (JPanel) this.getContentPane();
        JButton logout = new JButton("注销");
        JButton solitaireGame = new JButton("单人游戏");
        JButton doubleGame = new JButton("双人游戏");
        JButton selection = new JButton("查询");
        JTextPane nameArea = new JTextPane();
        MutableAttributeSet White = new SimpleAttributeSet();
        JLabel userRank = new JLabel();
        JTextPane gameLevelText = new JTextPane();
        JComboBox<Integer> chooseGameLevel = new JComboBox<>();
        String[] columnNames = new String[]{"排名", "账户名", "分数"};
        String[][] data = new String[][]{};
        JTable rankTable = new JTable();
        String[] rankRaw = new String[3];

        background.setBounds(0, 0, GameUtils.startImage.getIconWidth(), GameUtils.startImage.getIconHeight());
        this.getLayeredPane().add(background, Integer.MIN_VALUE);

        jPanel.setOpaque(false);
        jPanel.setLayout(null);

        solitaireGame.setFont(new Font("微软雅黑", Font.PLAIN,20));
        solitaireGame.setBounds(400, 200, 200, 50);
        solitaireGame.addActionListener(e -> {
            dispose();
            Thread thread = new Thread(() -> {
               chooseLevel = new ChooseLevel(gameLevel, userInfoVO.getUsername());
                try {
                    chooseLevel.launch();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            });
            thread.start();
        });

        doubleGame.setFont(new Font("微软雅黑", Font.PLAIN,20));
        doubleGame.setBounds(400, 260, 200, 50);
        doubleGame.addActionListener(e -> {
            dispose();
            Thread thread = new Thread(() -> {
                try {
                    chooseLevel = new ChooseLevel(gameLevel, userInfoVO.getUsername(), true);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                try {
                    chooseLevel.launch();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            });
            thread.start();
        });

        StyleConstants.setForeground(White, Color.WHITE);
        nameArea.setFont(new Font("微软雅黑", Font.PLAIN,20));
        nameArea.setBounds(0, 0, nameSize * 12, 30);
        nameArea.getDocument().insertString(nameArea.getDocument().getLength(), userInfoVO.getUsername(), White);
        nameArea.setEditable(false);
        nameArea.setOpaque(false);

        logout.setFont(new Font("微软雅黑", Font.PLAIN,18));
        logout.setBounds(nameSize * 13, 0, 80, 30);
        logout.addActionListener(e ->{
            this.dispose();
            startView.launch();
        });

        userRank.setBounds(20, 50, 200, 300);
        userRank.setBackground(Color.WHITE);

        gameLevelText.getDocument().insertString(gameLevelText.getDocument().getLength(), "关卡:", White);
        gameLevelText.setBounds(0, 0, 70, 30);
        gameLevelText.setFont(new Font("微软雅黑", Font.PLAIN,20));
        gameLevelText.setEditable(false);
        gameLevelText.setOpaque(false);

        selection.setFont(new Font("微软雅黑", Font.PLAIN,20));
        selection.setBounds(110, 0, 80, 30);
        selection.addActionListener(e -> {
            DefaultTableModel defaultTableModel = new DefaultTableModel(data, columnNames){
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            defaultTableModel.addRow(columnNames);
            Query query = new Query();
            query.eqAnd("passGameLevel", chooseGameLevel.getSelectedItem());
            query.groupBy("username");
            query.orderBy("score", false);
            rankList = userRankMapper.selectForNum(query, 10);
            for (int i = 0;i < rankList.size();i ++){
                rankRaw[0] = i + 1 + "";
                rankRaw[1] = rankList.get(i).getUsername();
                rankRaw[2] = rankList.get(i).getScore() + "";
                defaultTableModel.addRow(rankRaw);
                rankTable.setBounds(0, 40, 200, rankList.size() * 30);
            }
            rankTable.setModel(defaultTableModel);
        });
        rankTable.setFont(new Font("微软雅黑", Font.PLAIN,15));
        for (int i = 1; i <= gameLevel; i++) {
            chooseGameLevel.addItem(i);
        }
        chooseGameLevel.setBounds(60, 0, 40, 30);
        chooseGameLevel.setFont(new Font("微软雅黑", Font.PLAIN, 20));

        userRank.add(gameLevelText);
        userRank.add(selection);
        userRank.add(chooseGameLevel);
        userRank.add(rankTable);

        this.getLayeredPane().add(solitaireGame, (Integer)10);
        this.getLayeredPane().add(doubleGame, (Integer)10);
        this.getLayeredPane().add(nameArea, (Integer)10);
        this.getLayeredPane().add(logout, (Integer)10);
        this.getLayeredPane().add(userRank, (Integer)10);

        this.setVisible(true);
    }
}