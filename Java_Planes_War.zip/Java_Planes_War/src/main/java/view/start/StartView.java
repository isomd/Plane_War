package view.start;

import model.user_Server.entity.UserInfoVO;
import org.junit.Test;
import view.utils.GameUtils;

import javax.swing.*;
import javax.swing.text.BadLocationException;
import java.awt.*;
import java.io.*;
import java.net.Socket;

import static view.utils.GameUtils.mainView;

public class StartView extends JFrame{

    Socket socket = null;
    private BufferedReader reader = null;
    private BufferedWriter writer = null;

    public StartView() throws HeadlessException {
    }

    public StartView(Socket socket) throws HeadlessException, ClassNotFoundException {
        this.socket = socket;
        try{
            reader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
            writer = new BufferedWriter(new OutputStreamWriter(this.socket.getOutputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void launch() {
        this.setIconImage(GameUtils.IconImage);
        this.setTitle("登录");
        this.setSize(512,300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setFont(new Font("微软雅黑", Font.PLAIN,15));

        JLabel jLabel = new JLabel();
        JTextArea loginArea = new JTextArea("账号：");
        JTextField jTextField = new JTextField();
        JTextArea passwordArea = new JTextArea("密码：");
        JPasswordField jPasswordField = new JPasswordField();


        loginArea.setBounds(110,45,30,30);
        loginArea.setBackground(null);
        loginArea.setFont(new Font("微软雅黑", Font.PLAIN,15));
        loginArea.setEditable(false);

        jTextField.setBounds(150,40,200,30);
        jTextField.setFont(new Font("微软雅黑", Font.PLAIN,15));

        passwordArea.setBounds(110,75,30,30);
        passwordArea.setBackground(null);
        passwordArea.setFont(new Font("微软雅黑", Font.PLAIN,15));
        passwordArea.setEditable(false);

        jPasswordField.setBounds(150,70,200,30);
        jPasswordField.setFont(new Font("微软雅黑", Font.PLAIN,15));

        JButton jButton = new JButton("登录");
        jButton.setBounds(150, 105 , 100, 40);
        jButton.addActionListener(e -> {
            try {
                sendLoginMessage(jTextField.getText(), new String(jPasswordField.getPassword()));
                String msg = reader.readLine();
                if(!msg.equals("")) {
                    UserInfoVO user = new UserInfoVO();
                    user.valueForString(msg);
                    mainView = new MainView(user, 2, socket);
                    mainView.launch();
                    dispose();
                }
                else {
                    JFrame success = new JFrame("警告！");
                    success.setBounds(0,0,300,150);
                    success.setLocationRelativeTo(null);

                    JLabel jl = new JLabel();

                    JTextArea jt = new JTextArea("密码或账号错误！");
                    jt.setBounds(100,40,100, 30);
                    jt.setEditable(false);
                    jt.setBackground(null);
                    jl.add(jt);

                    JButton quit = new JButton("确认");
                    quit.setBounds(210, 70, 70, 30);
                    quit.addActionListener(e1 -> success.dispose());
                    jl.add(quit);
                    success.add(jl);
                    success.setVisible(true);
                }
            } catch (IOException | ClassNotFoundException | BadLocationException ex) {
                ex.printStackTrace();
            }
        });
        JButton jButton2 = new JButton("注册");
        jButton2.setBounds(255, 105 , 100, 40);
        jButton2.addActionListener(e -> Register());

        jLabel.add(jButton2);
        jLabel.add(jButton);
        jLabel.add(passwordArea);
        jLabel.add(jPasswordField);
        jLabel.add(jTextField);
        jLabel.add(loginArea);
        this.add(jLabel);
        this.setVisible(true);
    }
//    @Test
    public void Register(){
        JFrame jFrame = new JFrame("Register");
        jFrame.setBounds(0,0,500,200);
        jFrame.setLocationRelativeTo(null);

        JLabel jb2 = new JLabel();

        JTextArea jt1 = new JTextArea("账号：");
        jt1.setBounds(120,15,30,30);
        jt1.setBackground(null);
        jt1.setEditable(false);
        jb2.add(jt1);

        JTextField jTextField = new JTextField();
        jTextField.setBounds(150,10,200,30);
        jb2.add(jTextField,"North");

        JTextArea jt2 = new JTextArea("密码：");
        jt2.setBounds(120,45,30,30);
        jt2.setBackground(null);
        jt2.setEditable(false);
        jb2.add(jt2);

        JPasswordField jPasswordField = new JPasswordField();
        jPasswordField.setBounds(150,40,200,30);
        jb2.add(jPasswordField);

        JTextArea jt3 = new JTextArea("确认密码：");
        jt3.setBounds(90,75,60,30);
        jt3.setBackground(null);
        jt3.setEditable(false);
        jb2.add(jt3);

        JPasswordField jPasswordField_Again = new JPasswordField();
        jPasswordField_Again.setBounds(150,70,200,30);
        jb2.add(jPasswordField_Again);

        JButton jButton = new JButton("注册");
        jButton.setBounds(155,105,195, 40);
        jButton.addActionListener(e -> {
            try {
                sendRegisterMessage(jTextField.getText(), new String(jPasswordField.getPassword()), new String(jPasswordField_Again.getPassword()));
                if(!reader.readLine().equals("")){
                    JFrame success = new JFrame("注册成功");
                    success.setBounds(0,0,300,150);
                    success.setLocationRelativeTo(null);

                    JLabel jl = new JLabel();

                    JTextArea jt = new JTextArea("注册成功！");
                    jt.setBounds(100,40,100, 30);
                    jt.setEditable(false);
                    jt.setBackground(null);
                    jl.add(jt);

                    JButton quit = new JButton("返回登录");
                    quit.setBounds(140, 70, 140, 30);
                    quit.addActionListener(e1 -> success.dispose());
                    jl.add(quit);
                    success.add(jl);
                    success.setVisible(true);
                    jFrame.dispose();
                }
                else {
                    JFrame warning = new JFrame("警告！");
                    warning.setBounds(0,0,300,150);
                    warning.setLocationRelativeTo(null);

                    JLabel jl = new JLabel();

                    JTextArea jt = new JTextArea("两次密码不一致或账号重复！");
                    jt.setBounds(100,40,180, 30);
                    jt.setEditable(false);
                    jt.setBackground(null);
                    jl.add(jt);

                    JButton quit = new JButton("确认");
                    quit.setBounds(210, 70, 70, 30);
                    quit.addActionListener(e1 -> warning.dispose());
                    jl.add(quit);
                    warning.add(jl);
                    warning.setVisible(true);
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
        jb2.add(jButton);
        jFrame.add(jb2);
        jFrame.setVisible(true);
    }
    private void sendLoginMessage(String username, String password) throws IOException {
        writer.write("Login Message:");
        writer.newLine();
        writer.flush();
        writer.write(username);
        writer.newLine();
        writer.flush();
        writer.write(password);
        writer.newLine();
        writer.flush();
    }

    private void sendRegisterMessage(String username, String password, String password2) throws IOException {
        writer.write("Register Message:");
        writer.newLine();
        writer.flush();
        writer.write(username);
        writer.newLine();
        writer.flush();
        writer.write(password);
        writer.newLine();
        writer.flush();
        writer.write(password2);
        writer.newLine();
        writer.flush();
    }
}
