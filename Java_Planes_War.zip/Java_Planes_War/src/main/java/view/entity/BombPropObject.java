package view.entity;

import view.gameplaying.GamePlayingView;
import view.utils.GameUtils;

import java.awt.*;

public class BombPropObject extends PropObject{
    public BombPropObject(Image image, int x, int y, int width, int height) {
        super(image, x, y, width, height);
    }

    @Override
    public void function(GameObject myPlane) {
        for (int i = 0; i < GameUtils.enemyObjects.size(); i ++)
        {
                GameUtils.BombObjects.add(new BombObject(GameUtils.enemyObjects.get(i).getX(), GameUtils.enemyObjects.get(i).getY()));
                GameUtils.enemyObjects.remove(i);
                i --;
                GamePlayingView.GameScore += 10;
        }
    }

    @Override
    public void paintSelf(Graphics g) {
        super.paintSelf(g);
        super.y += 1;
    }
}
