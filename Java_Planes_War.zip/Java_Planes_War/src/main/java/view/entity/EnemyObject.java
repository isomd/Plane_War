package view.entity;

import view.gameplaying.GamePlayingView;
import view.utils.GameUtils;

import java.awt.*;

public class EnemyObject extends GameObject{
    boolean flag = true;
    public EnemyObject(Image image, int x, int y, int width, int height, int speed) {
        super(image, x, y, width, height, speed);
    }

    public EnemyObject(Image image, int x, int y, int speed) {
        super(image, x, y, speed);
    }

    public EnemyObject(Image image, int x, int y, int width, int height, int speed, int blood) {
        super(image, x, y, width, height, speed, blood);
    }

    public EnemyObject() {
    }

    @Override
    public void paintSelf(Graphics g) {
        super.paintSelf(g);
    }

    public void fire(GamePlayingView gamePlayingView, MyPlane myPlane){
        if (this.y == 100)
        GameUtils.enemyShellObject.add(new ShellObject(GameUtils.enemyShellImage, this.getX() + this.getWidth() / 2 - 15, this.getY(), 29, 65, 5, 20, this));
    }

    public void move(){
        this.y += this.speed;
        if(this.x <= 0) {
            flag = true;
            this.x += this.speed;
        }
        else if(this.x >= 424) {
            flag = false;
            this.x -= this.speed;
        }
        if(flag){
            this.x += this.speed;
        }
        else this.x -= this.speed;
    }
}
