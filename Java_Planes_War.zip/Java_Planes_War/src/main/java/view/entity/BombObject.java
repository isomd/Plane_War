package view.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import view.utils.GameUtils;

import java.awt.*;

@EqualsAndHashCode(callSuper = true)
@Data
public class BombObject extends GameObject{
    int x;
    int y;
    int count;
    public BombObject(int x, int y) {
        this.x = x;
        this.y = y;
        count = 0;
    }

    @Override
    public void paintSelf(Graphics g) {
        g.drawImage(GameUtils.bomb[count / 2], x, y, null);
        count++;
    }
}
