package view.entity;

import lombok.Data;

import java.awt.*;

@Data
public class GameObject {
    //实例图片
    Image image;
    //坐标x
    int x;
    //坐标y
    int y;
    //宽
    int width;
    //高
    int height;
    //速度
    int speed;
    //血量
    int blood;

    public GameObject(Image image, int x, int y, int width, int height, int speed) {
        this.image = image;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.speed = speed;
    }

    public GameObject(Image image, int x, int y, int width, int height, int speed, int blood) {
        this.image = image;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.speed = speed;
        this.blood = blood;
    }

    public GameObject(Image image, int x, int y, int speed) {
        this.image = image;
        this.x = x;
        this.y = y;
        this.speed = speed;
    }

    public GameObject() {
    }

    public void paintSelf(Graphics g) {
        g.drawImage(image, x, y, null);
    }

    public Rectangle getRec() {
        return new Rectangle(x, y, width, height);
    }

    public boolean isImpact(GameObject gameObject) {
        return this.getRec().intersects(gameObject.getRec());
    }
    public boolean isInArea() {
        return y >= -10 && y <= 768;
    }
}
