package view.entity;

import lombok.Data;

import java.awt.*;

@Data
public abstract class PropObject {
    Image image;
    int x;
    int y;
    int width;
    int height;

    public PropObject(Image image, int x, int y, int width, int height) {
        this.image = image;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public PropObject() {
    }
    public void paintSelf(Graphics g){
     g.drawImage(image,x,y,null);
    }
    public abstract void function(GameObject myPlane);

    public Rectangle getRec() {
        return new Rectangle(x, y, width, height);
    }

    public boolean isImpact(GameObject gameObject) {
        return this.getRec().intersects(gameObject.getRec());
    }
}
