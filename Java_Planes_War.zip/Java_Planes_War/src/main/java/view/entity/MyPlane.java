package view.entity;

import view.gameplaying.GamePlayingView;
import view.utils.GameUtils;

import java.awt.*;

public class MyPlane extends GameObject{
    public MyPlane(int x, int y, int speed) {
        super(GameUtils.myPlaneImage, x, y, speed);
    }

    public MyPlane(Image image, int x, int y, int width, int height, int speed) {
        super(image, x, y, width, height, speed);
    }

    public MyPlane(Image image, int x, int y, int width, int height, int speed, int blood) {
        super(image, x, y, width, height, speed, blood);
    }

    public MyPlane() {
    }
    @Override
    public void paintSelf(Graphics g){
        super.paintSelf(g);
    }

    @Override
    public boolean isImpact(GameObject gameObject) {
        return super.isImpact(gameObject);
    }

    public void leftMove(){
        this.x = Math.max(this.x - this.speed, 20);
    }
    public void rightMove(){
        this.x = Math.min(this.x + this.speed, GamePlayingView.WIDTH -this.width - 20);
    }
    public void upMove(){
        this.y = Math.max(this.y - this.speed, 10);
    }
    public void downMove(){
        this.y = Math.min(this.y + this.speed, GamePlayingView.HEIGHT - this.height - 20);
    }
}
