package view.entity;

import java.awt.*;

public class BloodPropObject extends PropObject {
    public BloodPropObject(Image image, int x, int y, int width, int height) {
        super(image, x, y, width, height);
    }

    public BloodPropObject() {
    }

    @Override
    public void function(GameObject myPlane) {
        myPlane.setBlood(Math.min(myPlane.getX() + 20, 100));
    }

    @Override
    public void paintSelf(Graphics g) {
        super.paintSelf(g);
        super.y += 1;
    }
}
