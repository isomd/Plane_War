package view.entity;

import java.awt.*;

public class ShellObject extends GameObject{
    GameObject Owner;
    public ShellObject(Image image, int x, int y, int speed) {
        super(image, x, y, speed);
    }

    public ShellObject(Image image, int x, int y, int width, int height, int speed, int blood, GameObject owner) {
        super(image, x, y, width, height, speed, blood);
        Owner = owner;
    }

    public ShellObject(Image image, int x, int y, int width, int height, int speed) {
        super(image, x, y, width, height, speed);
    }

    public ShellObject(Image image, int x, int y, int width, int height, int speed, int blood) {
        super(image, x, y, width, height, speed, blood);
    }

    public ShellObject() {
        super();
    }

    @Override
    public void paintSelf(Graphics g) {
        super.paintSelf(g);
        this.y -= this.speed;
    }

    public void enemyShellPaint(Graphics g){
        super.paintSelf(g);
        this.y += this.speed;
    }

    @Override
    public boolean isImpact(GameObject gameObject) {
        if(gameObject == Owner) return false;
        return super.isImpact(gameObject);
    }
}
